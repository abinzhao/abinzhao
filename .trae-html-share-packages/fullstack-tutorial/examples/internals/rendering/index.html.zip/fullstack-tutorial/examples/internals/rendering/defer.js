globalThis.loadTrace.push(`defer: ${document.readyState}; box exists: ${Boolean(document.querySelector('#box'))}`);
