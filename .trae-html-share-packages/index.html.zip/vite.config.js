import { defineConfig } from 'vite';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { lessons } from './src/curriculum.js';
import { renderMarkdown } from './build/markdown.js';
import { renderShell } from './src/template.js';

const contentDirectory = fileURLToPath(new URL('./content/', import.meta.url));
function loadCourse() {
  return lessons.map(lesson => {
    const markdown = readFileSync(`${contentDirectory}${lesson.id}.md`, 'utf8');
    return { ...lesson, ...renderMarkdown(markdown), searchText: markdown.replace(/<[^>]*>/g, '').replace(/[`#*>]/g, '') };
  });
}

export default defineConfig({
  base: './',
  plugins: [{
    name: 'course-markdown',
    resolveId(id) {
      if (id === 'virtual:course') return '\0virtual:course';
    },
    load(id) {
      if (id === '\0virtual:course') {
        for (const lesson of lessons) this.addWatchFile(`${contentDirectory}${lesson.id}.md`);
        return `export default ${JSON.stringify(loadCourse())}`;
      }
    },
    transformIndexHtml() {
      return [{ tag: 'noscript', children: '<p style="padding:16px">请启用 JavaScript 以切换教程、搜索和复制代码；第一篇教程仍可直接阅读。</p>', injectTo: 'body' }];
    },
    configureServer(server) {
      server.watcher.add(contentDirectory);
      server.watcher.on('change', file => {
        if (file.startsWith(contentDirectory)) {
          const module = server.moduleGraph.getModuleById('\0virtual:course');
          if (module) server.moduleGraph.invalidateModule(module);
          server.ws.send({ type: 'full-reload' });
        }
      });
    },
  }, {
    name: 'prerender-first-lesson',
    transformIndexHtml: {
      order: 'pre',
      handler(html) {
        return html.replace('<!--app-->', renderShell(loadCourse()));
      },
    },
  }],
  build: { target: 'es2022', cssCodeSplit: false, assetsInlineLimit: 4096 },
});
