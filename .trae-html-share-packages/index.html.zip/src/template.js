import { modules } from './curriculum.js';
import { icon, escapeHtml as e } from './icons.js';

export function renderSidebar(course) {
  return `<a class="brand" href="#/frontend/welcome" aria-label="Stack 从零开始"><span class="brand-mark">${icon('code')}</span><span>stack<span class="brand-dot">.</span><small>从零开始，步步进阶</small></span></a>
    <button class="search-trigger" data-search>${icon('search')}<span>搜索教程...</span><kbd>⌘ K</kbd></button>
    <nav class="course-nav" aria-label="课程导航">
      <a class="path-nav" href="#/path">${icon('route')}<span>学习路线总览</span>${icon('arrow')}</a>
      <div class="nav-label">你的全栈学习之旅 <span>5 个阶段</span></div>
      ${modules.map((module, index) => `<details class="module-nav" data-module="${module.id}" ${index === 0 ? 'open' : ''}>
        <summary><span class="module-number">0${index + 1}</span><span>${module.title}</span>${icon('down')}</summary>
        <div class="lesson-links">${course.filter(lesson => lesson.moduleId === module.id).map(lesson => `<a href="#/${lesson.id}" data-lesson-link="${lesson.id}" ${lesson.id === course[0].id ? 'class="active" aria-current="page"' : ''}><span class="lesson-dot"></span><span>${e(lesson.title)}</span><span class="lesson-done" aria-label="已学完"></span></a>`).join('')}</div>
      </details>`).join('')}
      <a class="guide-link" href="#/frontend/welcome?section=怎样使用这份教程">${icon('book')}阅读与学习指南${icon('external')}</a>
    </nav>
    <div class="sidebar-bottom"><div class="progress-label"><span>${icon('signal')} 我的学习进度</span><strong data-progress-text>0 / ${course.length}</strong></div><div class="progress-track" role="progressbar" aria-label="已完成课程" aria-valuemin="0" aria-valuemax="${course.length}" aria-valuenow="0"><span data-progress-bar></span></div><p>每一个小进步，都算数。${icon('spark')}</p></div>`;
}

function lessonFooter(lesson, course) {
  const index = course.findIndex(item => item.id === lesson.id);
  const prev = course[index - 1];
  const next = course[index + 1];
  return `<div class="lesson-finish"><div><span class="finish-symbol">${icon('check')}</span><div><strong>又向前走了一小步</strong><p>亲手运行示例后，再给自己打个勾。</p></div></div><button class="complete-button" data-complete="${lesson.id}">${icon('check')}<span>标记为已学完</span></button></div>
    <nav class="page-pagination" aria-label="上一篇和下一篇">${prev ? `<a href="#/${prev.id}"><small>${icon('back')} 上一篇</small><strong>${e(prev.title)}</strong></a>` : `<a href="#/path"><small>${icon('route')} 课程导航</small><strong>查看完整学习路线</strong></a>`}${next ? `<a class="next" href="#/${next.id}"><small>接下来学习 ${icon('arrow')}</small><strong>${e(next.title)}</strong></a>` : `<a class="next" href="#/path"><small>完成入门之旅 ${icon('arrow')}</small><strong>回顾你的学习路线</strong></a>`}</nav>`;
}

export function renderLesson(lesson, course) {
  const first = lesson.id === 'frontend/welcome';
  return `<div class="reading-layout"><article class="lesson-article">
    <div class="breadcrumbs"><a href="#/path">学习路线</a>${icon('chevron')}<a href="#/${course.find(item => item.moduleId === lesson.moduleId).id}">${e(lesson.moduleTitle)}</a>${icon('chevron')}<span>${first ? '开始之前' : lesson.number}</span></div>
    <header class="lesson-header"><div class="eyebrow"><span class="eyebrow-dot"></span>${first ? 'HELLO, WORLD. HELLO, YOU.' : modules[lesson.moduleIndex].label}<span class="lesson-tag">${e(lesson.tag)}</span></div>
    <h1 id="page-title" tabindex="-1">${e(lesson.title)}<span class="title-period">.</span></h1>
    <p class="lesson-description">${e(lesson.description)}</p>
    <div class="lesson-meta"><span>${icon('clock')} 约 ${lesson.minutes} 分钟</span><span>${icon('signal')} ${first ? '零基础友好' : '循序渐进'}</span><span>${icon('code')} ${first ? '边学边做' : '完整示例'}</span><span class="meta-index">LESSON ${String(course.indexOf(lesson) + 1).padStart(2, '0')} / ${course.length}</span></div></header>
    <div class="prose">${lesson.html}</div>${lessonFooter(lesson, course)}
    <footer class="article-footer"><span>stack. <span>学一点，做一点，向前一点。</span></span><a href="#/${lesson.id}" data-top>回到顶部 ↑</a></footer>
    </article><aside class="right-rail" aria-label="本页目录"><div class="toc-label">本页目录</div><nav class="toc">${lesson.toc.map((heading, index) => `<a href="#/${lesson.id}?section=${encodeURIComponent(heading.id)}" data-toc="${e(heading.id)}" class="${heading.depth === 3 ? 'nested ' : ''}${index === 0 ? 'current' : ''}">${e(heading.title)}</a>`).join('')}</nav>
    <div class="rail-note"><span class="rail-note-icon">${icon('bulb')}</span><strong>慢一点，也没关系。</strong><p>编程不是记住所有答案，<br>而是学会一步步找到答案。</p><a href="#/frontend/welcome?section=怎样使用这份教程">找到适合你的节奏 ${icon('arrow')}</a></div>
    <div class="rail-bottom">${icon('terminal')} BUILT TO HELP YOU BUILD</div></aside></div>`;
}

export function renderPath(course, completed = []) {
  return `<div class="path-page"><div class="breadcrumbs">你的全栈学习之旅 ${icon('chevron')} 学习路线总览</div>
    <header class="path-header"><div class="eyebrow"><span class="eyebrow-dot"></span>ONE STEP AT A TIME</div><h1 id="page-title" tabindex="-1">每一步，都离创造更近。</h1><p>不用一次学会所有。沿着这条路线，从第一个网页走向完整的应用。</p><div class="path-stats"><span><strong>5</strong> 个学习阶段</span><span><strong>${course.length}</strong> 篇动手教程</span><span><strong>${Math.round(course.reduce((sum, item) => sum + item.minutes, 0) / 60)}</strong> 小时建议实践</span></div></header>
    <div class="path-stages">${modules.map((module, i) => {
      const items = course.filter(lesson => lesson.moduleId === module.id);
      return `<section class="path-stage ${module.color}"><div class="stage-index">0${i + 1}</div><div class="stage-content"><div class="stage-heading"><span class="stage-icon">${icon(module.icon)}</span><div><small>${module.label}</small><h2>${module.title}</h2></div><span class="stage-count">${items.filter(item => completed.includes(item.id)).length} / ${items.length} 已学完</span></div><p>${module.description}</p><div class="stage-lessons">${items.map(lesson => `<a href="#/${lesson.id}"><span>${completed.includes(lesson.id) ? icon('check') : `<span class="stage-lesson-number">${lesson.number}</span>`}${e(lesson.title)}</span><small>${lesson.minutes} 分钟 ${icon('arrow')}</small></a>`).join('')}</div></div></section>`;
    }).join('')}</div><div class="path-end">${icon('spark')} 入门是起点。把学到的知识，变成属于自己的作品。</div></div>`;
}

export function renderShell(course) {
  return `<a class="skip-link" href="#main">跳转到正文</a><aside class="sidebar" id="sidebar">${renderSidebar(course)}</aside><div class="mobile-backdrop" data-close-nav></div>
    <div class="workspace"><header class="topbar"><button class="mobile-menu icon-button" data-menu aria-label="展开课程导航" aria-expanded="false" aria-controls="sidebar">${icon('menu')}</button><nav aria-label="主导航"><a href="#/frontend/welcome" data-tab="docs" class="active">教程文档</a><a href="#/path" data-tab="path">学习路线</a><a href="#/frontend/welcome?section=怎样使用这份教程" class="header-guide">学习指南${icon('external')}</a></nav><div class="topbar-right"><span class="course-status"><i></i>开放学习 · 自由探索</span><span class="topbar-separator"></span><button class="icon-button" data-search aria-label="搜索教程">${icon('search')}</button></div></header>
    <main id="main">${renderLesson(course[0], course)}</main></div>
    <dialog id="search-dialog" aria-labelledby="search-title"><form method="dialog"><div class="search-dialog-heading"><h2 id="search-title">找到你的下一步</h2><button class="icon-button" aria-label="关闭搜索">${icon('close')}</button></div></form><div class="search-field">${icon('search')}<input id="search-input" type="search" autocomplete="off" placeholder="搜索知识点、教程或代码..." aria-label="搜索课程"></div><div id="search-results" role="region" aria-live="polite"></div><div class="search-hint"><span>输入关键词，快速找到教程</span><kbd>ESC 关闭</kbd></div></dialog><div id="toast" role="status" aria-live="polite"></div>`;
}
