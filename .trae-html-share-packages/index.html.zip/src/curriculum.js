export const modules = [
  {
    id: 'frontend', title: '前端基础', subtitle: '让想法，第一次出现在屏幕上', icon: 'globe', color: 'lime', label: 'FOUNDATIONS',
    description: '从认识网页开始，用 HTML、CSS 和 JavaScript 做出你的第一个交互页面。',
    lessons: [
      ['welcome', '你好，未来的全栈工程师', 8, '学习起点', '不需要任何编程经验。从一个小小的网页开始，开启你的全栈学习旅程。'],
      ['web', '认识 Web 与互联网', 12, '基础概念', '网址、浏览器、服务器究竟是什么？跟着一次网页请求，认识它们的分工。'],
      ['html', 'HTML：搭建网页的骨架', 20, '动手实践', '用标题、段落、链接与表单，把内容组织成一张真正的网页。'],
      ['css', 'CSS：让网页有自己的风格', 25, '动手实践', '认识选择器、盒模型和布局，把你的第一张网页变得更好看。'],
      ['javascript', 'JavaScript：让页面动起来', 30, '动手实践', '从变量和事件出发，写一个可以点击、可以计数的小应用。'],
    ],
  },
  {
    id: 'engineering', title: '现代前端工程化', subtitle: '从一个文件，到一个真正的项目', icon: 'terminal', color: 'blue', label: 'MODERN FRONTEND',
    description: '掌握终端、模块、Vite、TypeScript 与 React，建立有条理的开发方式。',
    lessons: [
      ['terminal', '终端与 npm 入门', 15, '工具准备', '认识命令行和软件包，准备好接下来会反复使用的开发工具。'],
      ['vite', '用 Vite 创建第一个项目', 20, '项目起步', '创建、运行和构建一个现代前端项目，理解开发与发布的区别。'],
      ['modules', '用模块组织 JavaScript', 20, '代码组织', '把计算逻辑和页面逻辑分开，用 import 与 export 连接文件。'],
      ['typescript', 'TypeScript：给数据标注类型', 25, '类型基础', '在运行之前发现一些错误，理解类型为开发带来的帮助。'],
      ['react', 'React：从组件开始', 30, '组件基础', '把页面拆成可以复用的组件，用状态驱动一个简单的计数器。'],
    ],
  },
  {
    id: 'backend', title: '后端开发', subtitle: '为你的页面，接上真正的数据', icon: 'server', color: 'violet', label: 'BACKEND DEVELOPMENT',
    description: '使用 Node.js 理解服务器、HTTP、接口与数据存储，完成前后端连接。',
    lessons: [
      ['node', 'Node.js：在浏览器之外运行', 15, '运行环境', '认识 JavaScript 的另一种运行方式，编写第一个本地脚本。'],
      ['http', '创建你的第一个 HTTP 服务', 25, '网络基础', '用 Node.js 内置模块启动服务，亲手观察请求与响应。'],
      ['api', '设计一个 JSON API', 30, '接口实践', '通过请求方法、路径和状态码，构建一个简单的数据接口。'],
      ['storage', '让数据在重启后留下来', 25, '数据存储', '先用本地 JSON 文件理解持久化，再认识数据库要解决的问题。'],
      ['connect', '把前端与后端连接起来', 30, '全栈实践', '用 fetch 读取真实接口，处理加载、成功与失败三种状态。'],
    ],
  },
  {
    id: 'extension', title: '浏览器插件开发', subtitle: '把浏览器，变成你的工具箱', icon: 'puzzle', color: 'orange', label: 'BROWSER EXTENSIONS',
    description: '从 Manifest V3 出发，制作弹出面板、保存设置，并与网页交互。',
    lessons: [
      ['manifest', '认识插件与 Manifest V3', 20, '插件基础', '创建一个最小的 Chrome 插件，理解清单文件的作用。'],
      ['popup', '制作一个弹出面板', 25, '界面实践', '复用你的 HTML、CSS 和 JavaScript 知识，完成插件的小界面。'],
      ['storage', '用 Storage 保存设置', 25, '本地数据', '保存一条学习目标，让它在关闭面板之后依然存在。'],
      ['content', '让插件与网页互动', 30, '内容脚本', '在用户点击后读取当前网页标题，理解权限和执行环境。'],
      ['publish', '调试、打包与发布准备', 20, '交付检查', '找到错误日志，核对权限，并准备一个可分享的插件安装包。'],
    ],
  },
  {
    id: 'cross-platform', title: '跨端框架开发', subtitle: '让一份能力，抵达更多屏幕', icon: 'devices', color: 'pink', label: 'CROSS PLATFORM',
    description: '理解跨端的边界，从响应式与 PWA 走向 Tauri 桌面应用和 uni-app。',
    lessons: [
      ['overview', '认识跨端与技术选型', 15, '概念入门', '了解 Web、桌面和移动端各自的环境，选择合适的学习方向。'],
      ['responsive', '响应式：适配不同的屏幕', 25, '布局实践', '用弹性布局与媒体查询，让同一页面适应电脑和平板。'],
      ['pwa', 'PWA：让网页支持离线访问', 30, '渐进增强', '认识 Service Worker 与应用清单，制作一个可离线访问的网页。'],
      ['tauri', 'Tauri：第一个桌面窗口', 35, '桌面入门', '准备原生工具链，用 Tauri 2 把前端页面装进桌面窗口。'],
      ['uni-app', 'uni-app：第一个跨端页面', 35, '移动入门', '在 HBuilderX 中创建 Vue 3 项目，运行一个可点击的跨端页面。'],
    ],
  },
];

export const lessons = modules.flatMap((module, moduleIndex) => module.lessons.map((lesson, index) => ({
  id: `${module.id}/${lesson[0]}`, slug: lesson[0], title: lesson[1], minutes: lesson[2],
  tag: lesson[3], description: lesson[4], moduleId: module.id, moduleTitle: module.title,
  moduleIndex, index, number: `${moduleIndex + 1}.${index + 1}`,
})));
