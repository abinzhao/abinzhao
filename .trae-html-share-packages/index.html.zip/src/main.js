import './style.css';
import course from 'virtual:course';
import { modules } from './curriculum.js';
import { renderLesson, renderPath } from './template.js';
import { parseRoute, readProgress } from './routing.js';
import { icon, escapeHtml as e } from './icons.js';

const main = document.querySelector('#main');
const sidebar = document.querySelector('#sidebar');
const dialog = document.querySelector('#search-dialog');
const searchInput = document.querySelector('#search-input');
const progressKey = 'stack-learning-progress-v1';
const compact = matchMedia('(max-width: 760px)');
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
let completed = [];
try { completed = readProgress(localStorage.getItem(progressKey), course.map(lesson => lesson.id)); } catch { /* Reading stays available when storage is disabled. */ }
let currentId = course[0].id;
let toastTimeout;
let searchOpener;

function notify(message) {
  const toast = document.querySelector('#toast');
  toast.textContent = message;
  toast.classList.add('visible');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('visible'), 3000);
}

function updateProgress() {
  document.querySelector('[data-progress-text]').textContent = `${completed.length} / ${course.length}`;
  document.querySelector('[data-progress-bar]').style.width = `${completed.length / course.length * 100}%`;
  document.querySelector('[role="progressbar"]').setAttribute('aria-valuenow', completed.length);
  document.querySelectorAll('[data-lesson-link]').forEach(link => {
    const done = completed.includes(link.dataset.lessonLink);
    link.classList.toggle('done', done);
    link.querySelector('.lesson-done').innerHTML = done ? icon('check') : '';
  });
  const button = document.querySelector('[data-complete]');
  if (button) {
    const done = completed.includes(button.dataset.complete);
    button.classList.toggle('completed', done);
    button.setAttribute('aria-pressed', String(done));
    button.querySelector('span').textContent = done ? '已学完 · 点击撤销' : '标记为已学完';
  }
}

function setNav(open) {
  document.body.classList.toggle('nav-open', open);
  document.querySelector('[data-menu]').setAttribute('aria-expanded', String(open));
  sidebar.inert = compact.matches && !open;
  main.inert = compact.matches && open;
  if (open) sidebar.querySelector('a').focus();
}
compact.addEventListener('change', () => setNav(false));

function scrollToSection(section, smooth = true) {
  const target = document.getElementById(section);
  if (target) {
    target.scrollIntoView({ behavior: smooth && !reducedMotion.matches ? 'smooth' : 'instant', block: 'start' });
    target.focus({ preventScroll: true });
  } else {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }
}

function navigate(initial = false) {
  const route = parseRoute(location.hash);
  const lesson = course.find(item => item.id === route.lessonId);
  const nextId = route.page === 'path' ? 'path' : lesson?.id || 'not-found';
  const changed = currentId !== nextId;
  if (changed) {
    if (route.page === 'path') {
      main.innerHTML = renderPath(course, completed);
    } else if (lesson) {
      main.innerHTML = renderLesson(lesson, course);
    } else {
      main.innerHTML = `<div class="not-found"><span class="eyebrow">404 / LOST, BUT NOT STUCK</span><h1 id="page-title" tabindex="-1">这一页还不在学习路线上。</h1><p>地址可能有误。回到课程目录，继续下一步。</p><a class="primary-button" href="#/path">查看学习路线 ${icon('arrow')}</a></div>`;
    }
    currentId = nextId;
  }
  document.title = `${route.page === 'path' ? '学习路线' : lesson?.title || '未找到教程'} · Stack`;
  document.querySelector('meta[name="description"]').content = lesson?.description || '从零开始的全栈工程师学习路线，25 篇完整教程。';
  document.querySelectorAll('[data-lesson-link]').forEach(link => {
    const active = link.dataset.lessonLink === lesson?.id;
    link.classList.toggle('active', active);
    if (active) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  if (lesson) document.querySelector(`[data-module="${lesson.moduleId}"]`).open = true;
  document.querySelectorAll('[data-tab]').forEach(tab => {
    const active = tab.dataset.tab === (route.page === 'path' ? 'path' : 'docs');
    tab.classList.toggle('active', active);
    if (active) tab.setAttribute('aria-current', 'page');
    else tab.removeAttribute('aria-current');
  });
  document.querySelector('.path-nav').classList.toggle('active', route.page === 'path');
  document.querySelectorAll('[data-section]').forEach(link => {
    link.href = `#/${currentId}?section=${encodeURIComponent(link.dataset.section)}`;
  });
  setNav(false);
  updateProgress();
  if (route.section) requestAnimationFrame(() => scrollToSection(route.section, !initial));
  else if (!initial) {
    window.scrollTo({ top: 0, behavior: 'instant' });
    document.querySelector('#page-title')?.focus({ preventScroll: true });
  }
  updateToc();
}

function updateToc() {
  const headings = [...document.querySelectorAll('.prose h2[id], .prose h3[id]')];
  if (!headings.length) return;
  let current = headings[0].id;
  for (const heading of headings) {
    if (heading.getBoundingClientRect().top <= 180) current = heading.id;
  }
  for (const link of document.querySelectorAll('[data-toc]')) {
    const active = link.dataset.toc === current;
    link.classList.toggle('current', active);
    if (active) link.setAttribute('aria-current', 'location');
    else link.removeAttribute('aria-current');
  }
}

function search() {
  const query = searchInput.value.trim().toLocaleLowerCase();
  const terms = query.split(/\s+/).filter(Boolean);
  const results = course.filter(lesson => terms.every(term => `${lesson.title} ${lesson.moduleTitle} ${lesson.searchText}`.toLocaleLowerCase().includes(term)));
  document.querySelector('#search-results').innerHTML = `<p class="result-count">${query ? `找到 ${results.length} 篇教程` : '从这里开始探索'}</p>${results.length ? results.map(lesson => `<a class="search-result" href="#/${lesson.id}"><span class="search-result-icon">${icon(modules[lesson.moduleIndex].icon)}</span><span><small>${e(lesson.moduleTitle)} / ${lesson.number}</small><strong>${e(lesson.title)}</strong><p>${e(lesson.description)}</p></span>${icon('arrow')}</a>`).join('') : `<div class="empty-search">${icon('search')}<strong>还没有找到相关教程</strong><p>试试“HTML”“接口”或“插件”。</p></div>`}`;
}

async function copyCode(button) {
  const code = button.closest('.code-block').querySelector('code').textContent;
  try {
    if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(code);
    else {
      const textarea = document.createElement('textarea');
      textarea.value = code;
      textarea.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
      document.body.append(textarea);
      textarea.select();
      const success = document.execCommand('copy');
      textarea.remove();
      button.focus();
      if (!success) throw new Error('Clipboard unavailable');
    }
    button.innerHTML = `${icon('check')}<span>已复制</span>`;
    button.classList.add('copied');
    setTimeout(() => { button.innerHTML = `${icon('copy')}<span>复制代码</span>`; button.classList.remove('copied'); }, 2000);
  } catch {
    notify('浏览器未允许复制，请选中代码后手动复制。');
  }
}

document.addEventListener('click', event => {
  const target = event.target.closest('button, a, [data-close-nav]');
  if (!target) return;
  if (target.matches('[data-search]')) {
    searchOpener = target;
    searchInput.value = '';
    search();
    dialog.showModal();
    searchInput.focus();
  }
  if (target.matches('[data-copy]')) copyCode(target);
  if (target.matches('[data-menu]')) setNav(!document.body.classList.contains('nav-open'));
  if (target.matches('[data-close-nav]')) setNav(false);
  if (target.matches('[data-complete]')) {
    const id = target.dataset.complete;
    completed = completed.includes(id) ? completed.filter(item => item !== id) : [...completed, id];
    try { localStorage.setItem(progressKey, JSON.stringify(completed)); }
    catch { notify('已更新本次阅读进度；浏览器当前不允许保存到本地。'); }
    updateProgress();
  }
  if (target.matches('.search-result')) dialog.close();
  if (target.matches('a[href^="#/"]') && target.hash === location.hash) {
    event.preventDefault();
    navigate();
  }
});

searchInput.addEventListener('input', search);
dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
dialog.addEventListener('close', () => searchOpener?.focus({ preventScroll: true }));
document.addEventListener('keydown', event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    if (dialog.open) dialog.close();
    else document.querySelector('[data-search]').click();
  }
  if (event.key === 'Escape' && document.body.classList.contains('nav-open')) {
    setNav(false);
    document.querySelector('[data-menu]').focus();
  }
  if (dialog.open && ['ArrowDown', 'ArrowUp'].includes(event.key)) {
    const links = [...dialog.querySelectorAll('.search-result')];
    if (!links.length) return;
    event.preventDefault();
    const index = links.indexOf(document.activeElement);
    links[event.key === 'ArrowDown' ? Math.min(index + 1, links.length - 1) : Math.max(index - 1, 0)].focus();
  }
  if (event.key === 'Tab' && compact.matches && document.body.classList.contains('nav-open') && !dialog.open) {
    const focusable = [...sidebar.querySelectorAll('a, button, summary')].filter(element => element.checkVisibility());
    const first = focusable[0], last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});

window.addEventListener('hashchange', () => navigate());
let ticking = false;
window.addEventListener('scroll', () => {
  if (ticking) return;
  ticking = true;
  requestAnimationFrame(() => { updateToc(); ticking = false; });
}, { passive: true });
window.addEventListener('storage', event => {
  if (event.key !== progressKey) return;
  completed = readProgress(event.newValue, course.map(lesson => lesson.id));
  if (currentId === 'path') main.innerHTML = renderPath(course, completed);
  updateProgress();
});
navigate(true);
