export function parseRoute(hash) {
  const fallback = { page: 'lesson', lessonId: 'frontend/welcome', section: '' };
  try {
    const [path, query = ''] = hash.replace(/^#\/?/, '').split('?');
    if (!path) return fallback;
    if (path === 'path') return { page: 'path', section: '' };
    const lessonId = decodeURIComponent(path);
    if (!/^[a-z-]+\/[a-z-]+$/.test(lessonId)) return fallback;
    return { page: 'lesson', lessonId, section: new URLSearchParams(query).get('section') || '' };
  } catch {
    return fallback;
  }
}

export function readProgress(raw, lessonIds) {
  try {
    const value = JSON.parse(raw);
    return Array.isArray(value) ? [...new Set(value.filter(id => lessonIds.includes(id)))] : [];
  } catch {
    return [];
  }
}
