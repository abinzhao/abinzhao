import test from 'node:test';
import assert from 'node:assert/strict';

const routing = await import('../src/routing.js').catch(() => ({}));
const content = await import('../build/markdown.js').catch(() => ({}));

test('hash routes keep lesson navigation and Chinese section anchors independent', () => {
  assert.equal(typeof routing.parseRoute, 'function', 'route parser is implemented');
  assert.deepEqual(routing.parseRoute('#/frontend/html?section=创建文件'), {
    page: 'lesson', lessonId: 'frontend/html', section: '创建文件',
  });
});

test('empty and malformed hashes recover to a usable page', () => {
  assert.equal(typeof routing.parseRoute, 'function');
  assert.equal(routing.parseRoute('').lessonId, 'frontend/welcome');
  assert.equal(routing.parseRoute('#/%E0%A4%A').lessonId, 'frontend/welcome');
  assert.equal(routing.parseRoute('#/path').page, 'path');
});

test('saved progress ignores corrupt, duplicate and removed lesson IDs', () => {
  assert.equal(typeof routing.readProgress, 'function');
  assert.deepEqual(routing.readProgress('broken', ['a']), []);
  assert.deepEqual(routing.readProgress('{"a":true}', ['a']), []);
  assert.deepEqual(routing.readProgress('["a","a","removed",null]', ['a', 'b']), ['a']);
});

test('Markdown gives repeated headings unique anchors and a matching table of contents', () => {
  assert.equal(typeof content.renderMarkdown, 'function', 'Markdown renderer is implemented');
  const result = content.renderMarkdown('## 开始学习\n\n正文。\n\n## 开始学习');
  assert.equal(result.toc.length, 2);
  assert.notEqual(result.toc[0].id, result.toc[1].id);
  for (const heading of result.toc) assert.ok(result.html.includes(`id="${heading.id}"`));
});

test('code is escaped, highlighted and preserved for exact copying', () => {
  assert.equal(typeof content.renderMarkdown, 'function');
  const { html } = content.renderMarkdown('```html index.html\n<h1>你好</h1>\n<script>alert("hi")</script>\n```');
  assert.ok(html.includes('hljs'));
  assert.ok(html.includes('&lt;'));
  assert.ok(!html.includes('<script>alert'));
  assert.ok(html.includes('data-copy'));
  assert.ok(html.includes('index.html'));
});

test('unknown code languages remain readable and teaching callouts render', () => {
  assert.equal(typeof content.renderMarkdown, 'function');
  const { html } = content.renderMarkdown('> [!TIP]\n> 先保存，再刷新。\n\n```unknown\nhello <world>\n```');
  assert.ok(html.includes('callout'));
  assert.ok(html.includes('hello &lt;world&gt;'));
});
